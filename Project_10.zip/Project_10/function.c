<?xml version="1.0" encoding="UTF-8"?>
<workspace>
    <project>
        <path>$WS_DIR$\Project_04.ewp</path>
    </project>
    <batchBuild />
</workspace>
